def test_module_loads():
    from awx.sso import pipeline  # noqa
