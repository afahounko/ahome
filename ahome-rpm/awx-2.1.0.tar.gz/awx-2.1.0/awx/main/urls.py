# Copyright (c) 2015 Ansible, Inc.
# All Rights Reserved.

from django.conf.urls import patterns

urlpatterns = patterns()
